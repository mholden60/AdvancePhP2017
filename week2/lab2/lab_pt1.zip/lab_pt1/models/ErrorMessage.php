<?php

class ErrorMessage extends Message{}
